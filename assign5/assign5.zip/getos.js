const os = require('os');
console.log(`Type of OS you are using: ${os.platform()}`);